"""Super JT World — Pygame + Pygbag (browser/phone compatible)."""
import asyncio
import pygame
import random
import math
import os

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------
SCREEN_W, SCREEN_H = 800, 480
FPS = 60
TILE = 32
GRAVITY = 0.55
TERMINAL_VEL = 11
PLAYER_SPEED = 4
SPRINT_SPEED = 6.5
JUMP_FORCE = -11
COYOTE_MS = 90
JUMP_BUFFER_MS = 120

THEMES = [
    'grassland', 'underground', 'sky', 'desert', 'snow',
    'lava', 'ocean', 'factory', 'haunted', 'crystal',
]
SKY = {
    'grassland': (92, 148, 252), 'underground': (20, 15, 30),
    'sky': (135, 200, 255), 'desert': (255, 200, 120),
    'snow': (200, 215, 240), 'lava': (60, 15, 10),
    'ocean': (30, 80, 140), 'factory': (60, 60, 75),
    'haunted': (30, 20, 50), 'crystal': (40, 30, 80),
}

# Grid: row 0 = bottom of screen, row 14 = top
GRID_ROWS = 15

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
BASE = os.path.dirname(os.path.abspath(__file__))
TEX = os.path.join(BASE, 'assets', 'textures')
SFX = os.path.join(BASE, 'assets', 'sounds')
MUS = os.path.join(BASE, 'assets', 'music')


def _load_img(path, size=None):
    try:
        img = pygame.image.load(os.path.join(TEX, path)).convert_alpha()
        return pygame.transform.scale(img, size) if size else img
    except Exception:
        s = pygame.Surface(size or (TILE, TILE), pygame.SRCALPHA)
        s.fill((255, 0, 255, 180))
        return s


def _load_snd(name):
    try:
        return pygame.mixer.Sound(os.path.join(SFX, f'{name}.ogg'))
    except Exception:
        return None


def grid_to_px(gx, gy):
    """Convert grid coords (0=bottom) to screen pixel top-left."""
    return gx * TILE, (GRID_ROWS - 1 - gy) * TILE


# ---------------------------------------------------------------------------
# Assets
# ---------------------------------------------------------------------------
class Assets:
    def __init__(self):
        sz = (TILE, TILE)
        psz = (TILE, TILE + 14)

        self.jt_idle = _load_img('jt_idle.png', psz)
        self.jt_jump = _load_img('jt_jump.png', psz)
        self.jt_run = [_load_img(f'jt_run_{i}.png', psz) for i in range(4)]

        self.enemy = {
            'goomba': _load_img('enemy_goomba.png', sz),
            'koopa': _load_img('enemy_koopa.png', sz),
            'flying': _load_img('enemy_flying.png', sz),
            'boss': _load_img('enemy_boss.png', (TILE * 2, TILE * 2)),
        }
        self.powerup = {
            'mushroom': _load_img('powerup_mushroom.png', sz),
            'star': _load_img('powerup_star.png', sz),
            'fire_flower': _load_img('powerup_fire_flower.png', sz),
        }
        self.coin_img = _load_img('coin.png', (20, 20))

        self.tiles = {}
        self.bgs = {}
        for t in THEMES:
            self.tiles[t] = {
                'ground': _load_img(f'{t}/ground.png', sz),
                'brick': _load_img(f'{t}/brick.png', sz),
                'question': _load_img(f'{t}/question.png', sz),
                'question_used': self._make_used_block(t),
                'pipe': _load_img(f'{t}/pipe.png', sz),
            }
            self.bgs[t] = _load_img(f'{t}/background.png', (SCREEN_W, SCREEN_H))

        self.snd = {}
        for n in ['jump', 'coin', 'stomp', 'powerup', 'hit', 'death',
                   'oneup', 'brick_break', 'level_complete', 'pause', 'select']:
            s = _load_snd(n)
            if s:
                s.set_volume(0.5)
            self.snd[n] = s

    def _make_used_block(self, theme):
        s = pygame.Surface((TILE, TILE), pygame.SRCALPHA)
        s.fill((90, 80, 65, 255))
        pygame.draw.rect(s, (70, 60, 50), (0, 0, TILE, TILE), 2)
        return s

    def play(self, name):
        s = self.snd.get(name)
        if s:
            s.play()

    def music(self, track):
        p = os.path.join(MUS, f'{track}.ogg')
        try:
            pygame.mixer.music.load(p)
            pygame.mixer.music.set_volume(0.3)
            pygame.mixer.music.play(-1)
        except Exception:
            pass


# ---------------------------------------------------------------------------
# Level generator
# ---------------------------------------------------------------------------
class LevelGen:
    def __init__(self, seed=None):
        self.seed = seed or random.randint(0, 999999)

    def generate(self, level_num):
        rng = random.Random(self.seed + level_num * 1000)
        theme = THEMES[(level_num - 1) % len(THEMES)]
        diff = 1.0 + (level_num - 1) * 0.12
        n_chunks = 3 + min(level_num // 2, 7)
        CW = 40

        tiles = []       # (gx, gy, type)
        enemies = []     # (gx, gy, type)
        coins = []       # (gx, gy)
        mystery = []     # (gx, gy, reward)  — question blocks with items inside
        bricks = []      # (gx, gy)
        occupied = set() # track all placed tile positions

        for ci in range(n_chunks):
            ox = ci * CW
            x = 0
            gh = 2
            after_gap = False  # track if previous iteration was a gap

            while x < CW:
                # Gap — max 3 tiles for early levels, never more than 4
                max_gap = min(3 + int(diff * 0.5), 4)
                gap_chance = 0.08 * diff if level_num <= 3 else 0.12 * diff
                if rng.random() < gap_chance and x > 8 and ci > 0 and not after_gap:
                    gap_w = rng.randint(2, max_gap)
                    # Mark gap columns + 1 tile on each side as no-build at ALL heights
                    for gx in range(ox + x - 1, ox + x + gap_w + 2):
                        for gy in range(0, 15):
                            occupied.add((gx, gy))
                    x += gap_w
                    after_gap = True
                    continue

                seg = min(rng.randint(4, 12), CW - x)

                # After a gap: keep ground low so player can land safely
                if after_gap:
                    gh = max(1, min(gh, 2))  # flatten to max height 2
                    after_gap = False
                elif rng.random() < 0.3:
                    new_gh = rng.randint(1, min(4, int(2 + diff)))
                    gh = max(1, min(new_gh, gh + 2))
                else:
                    gh = max(1, gh + rng.randint(-1, 1))

                # Safe landing zone: first 3 tiles after gap have no obstacles
                safe_zone = 3 if not after_gap else 0

                for sx in range(seg):
                    gx = ox + x + sx
                    for gy in range(gh + 1):
                        tiles.append((gx, gy, 'ground'))
                        occupied.add((gx, gy))

                    # Coins in the air
                    if rng.random() < 0.3:
                        coins.append((gx, gh + 4))

                # Enemy on this segment (not in safe zone)
                if seg > 3 and rng.random() < 0.25 * diff:
                    min_ex = max(1, safe_zone)
                    if min_ex < seg - 1:
                        ex = ox + x + rng.randint(min_ex, seg - 2)
                        ey = gh + 1
                        ets = ['goomba', 'koopa']
                        if diff > 1.5:
                            ets.append('flying')
                        et = rng.choice(ets)
                        if et == 'flying':
                            ey += rng.randint(3, 6)
                        enemies.append((ex, ey, et))

                # Pipe (max 2 tall, never in first 4 tiles, leave jump clearance above)
                if rng.random() < 0.1 and seg > 6:
                    px = ox + x + rng.randint(max(4, safe_zone + 1), seg - 2)
                    ph = 2  # always 2 tiles tall — jumpable
                    for py in range(ph):
                        tiles.append((px, gh + 1 + py, 'pipe'))
                        occupied.add((px, gh + 1 + py))
                    # Reserve 3 tiles of clearance above pipe for jumping
                    pipe_top = gh + 1 + ph
                    for cy in range(pipe_top, pipe_top + 3):
                        occupied.add((px, cy))

                x += seg

            # Floating block rows — mix of bricks and mystery boxes
            for _ in range(rng.randint(1, 2 + int(diff * 0.5))):
                bx = ox + rng.randint(3, CW - 3)
                by = rng.randint(7, 10)
                blen = rng.randint(3, 6)
                for i in range(blen):
                    pos = (bx + i, by)
                    if pos in occupied:
                        continue
                    if rng.random() < 0.3:
                        reward = rng.choice(['coin', 'coin', 'coin', 'mushroom',
                                             'fire_flower', 'star'])
                        mystery.append((bx + i, by, reward))
                        tiles.append((bx + i, by, 'question'))
                    else:
                        bricks.append((bx + i, by))
                        tiles.append((bx + i, by, 'brick'))
                    occupied.add(pos)

            # Standalone mystery boxes (classic Mario style)
            for _ in range(rng.randint(0, 2)):
                mx = ox + rng.randint(5, CW - 5)
                my = rng.randint(7, 9)
                if (mx, my) in occupied:
                    continue
                reward = rng.choice(['coin', 'mushroom', 'star'])
                mystery.append((mx, my, reward))
                tiles.append((mx, my, 'question'))
                occupied.add((mx, my))

        # Boss every 5 levels
        is_boss = level_num % 5 == 0
        if is_boss:
            enemies.append((n_chunks * CW - 10, 3, 'boss'))

        flag_gx = n_chunks * CW - 3
        return {
            'tiles': tiles, 'enemies': enemies, 'coins': coins,
            'mystery': mystery, 'bricks': bricks,
            'theme': theme, 'width_gx': n_chunks * CW,
            'flag_gx': flag_gx, 'is_boss': is_boss,
        }


# ---------------------------------------------------------------------------
# World tile — supports bump animation, breaking, mystery rewards
# ---------------------------------------------------------------------------
class WorldTile:
    def __init__(self, gx, gy, ttype, theme_tiles):
        self.gx, self.gy = gx, gy
        self.ttype = ttype
        self.px, self.py = grid_to_px(gx, gy)
        self.base_py = self.py
        self.alive = True
        self.img = theme_tiles.get(ttype)
        self.used_img = theme_tiles.get('question_used')
        self.used = False  # for question blocks
        self.bump_vy = 0
        self.bumping = False
        self.breaking = False
        self.break_timer = 0
        self.break_pieces = []

    def rect(self):
        return pygame.Rect(self.px, self.py, TILE, TILE)

    def bump(self):
        """Called when player hits from below."""
        if self.bumping:
            return
        self.bumping = True
        self.bump_vy = -5

    def start_break(self):
        """Brick shatters into 4 pieces."""
        self.breaking = True
        self.break_timer = 0
        cx, cy = self.px + TILE // 2, self.py + TILE // 2
        for dx, dy in [(-1, -1), (1, -1), (-1, 0.5), (1, 0.5)]:
            self.break_pieces.append([cx, cy, dx * 3, dy * -6, 0])
        self.alive = False

    def update(self, dt):
        if self.bumping:
            self.py += self.bump_vy
            self.bump_vy += 0.8
            if self.py >= self.base_py:
                self.py = self.base_py
                self.bumping = False
                self.bump_vy = 0

        if self.breaking:
            self.break_timer += dt
            for p in self.break_pieces:
                p[0] += p[2]
                p[1] += p[3]
                p[3] += 0.4  # gravity
                p[4] += 3    # rotation

    def draw(self, surf, cam_x):
        if self.breaking:
            if self.break_timer < 600:
                col = (180, 100, 50)
                for p in self.break_pieces:
                    sx = p[0] - cam_x
                    pygame.draw.rect(surf, col, (sx, p[1], 10, 10))
            return

        if not self.alive:
            return

        sx = self.px - cam_x
        if sx < -TILE or sx > SCREEN_W + TILE:
            return

        if self.used and self.used_img:
            surf.blit(self.used_img, (sx, self.py))
        elif self.img:
            surf.blit(self.img, (sx, self.py))


# ---------------------------------------------------------------------------
# Pop-up item (coin / mushroom / star popping out of mystery box)
# ---------------------------------------------------------------------------
class PopItem:
    """Item that pops out of a mystery box with animation."""
    def __init__(self, x, y, reward, assets):
        self.x, self.y = x, y - TILE
        self.target_y = y - TILE - 10
        self.reward = reward
        self.assets = assets
        self.rising = True
        self.vy = -3
        self.alive = True
        self.grounded = False
        self.vx = 0
        self.timer = 0

        if reward == 'coin':
            self.is_coin = True
            self.vy = -6
        else:
            self.is_coin = False
            self.vx = 2  # mushroom / powerup slides

    def update(self, dt):
        self.timer += dt
        if self.is_coin:
            self.y += self.vy
            self.vy += 0.3
            if self.timer > 500:
                self.alive = False
        else:
            if self.rising:
                self.y += self.vy
                self.vy += 0.15
                if self.vy >= 0:
                    self.rising = False
            else:
                self.vy += GRAVITY * 0.5
                self.y += self.vy
                self.x += self.vx

    def rect(self):
        return pygame.Rect(self.x, self.y, TILE, TILE)

    def draw(self, surf, cam_x):
        if not self.alive:
            return
        sx = self.x - cam_x
        if self.is_coin:
            surf.blit(self.assets.coin_img, (sx + 6, self.y + 6))
        else:
            img = self.assets.powerup.get(self.reward)
            if img:
                surf.blit(img, (sx, self.y))


# ---------------------------------------------------------------------------
# Player
# ---------------------------------------------------------------------------
class Player:
    def __init__(self, assets):
        self.A = assets
        self.reset()

    def reset(self):
        self.x, self.y = 100.0, 300.0
        self.vx, self.vy = 0.0, 0.0
        self.w, self.h = TILE - 4, TILE + 12
        self.grounded = False
        self.facing_right = True
        self.alive = True
        self.score = 0
        self.coins = 0
        self.lives = 3
        self.health = 3
        self.big = False
        self.star = False
        self.star_t = 0
        self.inv = False
        self.inv_t = 0
        self.frame = 0
        self.anim_t = 0
        self.coyote = 0
        self.jbuf = 0
        self.dead_t = 0

    def rect(self):
        return pygame.Rect(self.x, self.y, self.w, self.h)

    def update(self, keys, touch, dt):
        if not self.alive:
            self.vy += GRAVITY
            self.y += self.vy
            self.dead_t += dt
            return

        mv = 0
        sprint = keys[pygame.K_LSHIFT] or keys[pygame.K_RSHIFT] or touch.get('sprint')
        spd = SPRINT_SPEED if sprint else PLAYER_SPEED

        if keys[pygame.K_a] or keys[pygame.K_LEFT] or touch.get('left'):
            mv = -1; self.facing_right = False
        if keys[pygame.K_d] or keys[pygame.K_RIGHT] or touch.get('right'):
            mv = 1; self.facing_right = True

        self.vx = mv * spd
        self.x += self.vx

        # Coyote / jump buffer
        if self.grounded:
            self.coyote = COYOTE_MS
        else:
            self.coyote = max(0, self.coyote - dt)

        jp = keys[pygame.K_SPACE] or keys[pygame.K_w] or keys[pygame.K_UP] or touch.get('jump')
        self.jbuf = JUMP_BUFFER_MS if jp else max(0, self.jbuf - dt)

        if self.jbuf > 0 and self.coyote > 0:
            self.vy = JUMP_FORCE
            self.jbuf = 0
            self.coyote = 0
            self.grounded = False
            self.A.play('jump')

        # Variable jump
        if not jp and self.vy < -2:
            self.vy *= 0.82

        self.vy = min(self.vy + GRAVITY, TERMINAL_VEL)
        self.y += self.vy

        # Timers
        if self.star:
            self.star_t -= dt
            if self.star_t <= 0:
                self.star = False
        if self.inv:
            self.inv_t -= dt
            if self.inv_t <= 0:
                self.inv = False

        # Animation
        self.anim_t += dt
        if self.anim_t > 90:
            self.anim_t = 0
            self.frame = (self.frame + 1) % 4

        if self.y > SCREEN_H + 200:
            self.die()

    def die(self):
        if not self.alive:
            return
        self.alive = False
        self.vy = JUMP_FORCE
        self.lives -= 1
        self.dead_t = 0
        self.A.play('death')

    def hit(self):
        if self.inv or self.star:
            return
        if self.big:
            self.big = False
            self.h = TILE + 12
            self.inv = True
            self.inv_t = 2000
            self.A.play('hit')
        else:
            self.health -= 1
            if self.health <= 0:
                self.die()
            else:
                self.inv = True
                self.inv_t = 2000
                self.A.play('hit')

    def collect_coin(self):
        self.coins += 1
        self.score += 100
        self.A.play('coin')
        if self.coins >= 100:
            self.coins -= 100
            self.lives += 1
            self.A.play('oneup')

    def collect_powerup(self, t):
        self.score += 500
        self.A.play('powerup')
        if t in ('mushroom', 'fire_flower'):
            if not self.big:
                self.big = True
                self.h = TILE + 24
            else:
                self.health = min(self.health + 1, 3)
        elif t == 'star':
            self.star = True
            self.star_t = 8000

    def draw(self, surf, cam_x):
        sx = self.x - cam_x
        if not self.alive:
            surf.blit(self.A.jt_idle, (sx, self.y))
            return
        if self.inv and (pygame.time.get_ticks() // 80) % 2:
            return

        if not self.grounded:
            img = self.A.jt_jump
        elif abs(self.vx) > 0.5:
            img = self.A.jt_run[self.frame]
        else:
            img = self.A.jt_idle

        if not self.facing_right:
            img = pygame.transform.flip(img, True, False)

        if self.star:
            tint = pygame.Surface(img.get_size(), pygame.SRCALPHA)
            t = pygame.time.get_ticks() / 200
            tint.fill((int(abs(math.sin(t)) * 128) + 127,
                        int(abs(math.sin(t + 2)) * 128) + 127,
                        int(abs(math.sin(t + 4)) * 128) + 127, 70))
            img = img.copy()
            img.blit(tint, (0, 0), special_flags=pygame.BLEND_RGBA_ADD)

        if self.big:
            img = pygame.transform.scale(img, (self.w + 8, TILE + 24))

        surf.blit(img, (sx, self.y))


# ---------------------------------------------------------------------------
# Enemy
# ---------------------------------------------------------------------------
class Enemy:
    def __init__(self, gx, gy, etype, assets):
        self.px, self.py = grid_to_px(gx, gy)
        self.etype = etype
        self.A = assets
        self.alive = True
        self.active = False
        self.dir = -1
        self.speed = {'goomba': 1.5, 'koopa': 2, 'flying': 1.2, 'boss': 1}[etype]
        self.spawn_x = self.px
        self.fly_t = 0
        self.base_py = self.py
        self.w = TILE * 2 if etype == 'boss' else TILE
        self.h = TILE * 2 if etype == 'boss' else TILE
        self.hp = 10 if etype == 'boss' else 1
        self.squish_t = 0

    def rect(self):
        return pygame.Rect(self.px, self.py, self.w, self.h)

    def update(self, dt):
        if not self.alive:
            self.squish_t += dt
            return
        if not self.active:
            return
        self.px += self.speed * self.dir
        if abs(self.px - self.spawn_x) > 160:
            self.dir *= -1
        if self.etype == 'flying':
            self.fly_t += dt / 1000
            self.py = self.base_py + math.sin(self.fly_t * 2.5) * 50

    def stomp(self):
        self.hp -= 1
        if self.hp <= 0:
            self.alive = False
            self.squish_t = 0
        return 200

    def draw(self, surf, cam_x):
        if not self.alive and self.squish_t > 400:
            return
        sx = self.px - cam_x
        if sx < -self.w * 2 or sx > SCREEN_W + self.w:
            return
        img = self.A.enemy.get(self.etype)
        if not img:
            return
        if not self.alive:
            img = pygame.transform.scale(img, (self.w, self.h // 4))
        elif self.dir > 0:
            img = pygame.transform.flip(img, True, False)
        surf.blit(img, (sx, self.py))


# ---------------------------------------------------------------------------
# Coin
# ---------------------------------------------------------------------------
class Coin:
    def __init__(self, gx, gy):
        self.px, self.py = grid_to_px(gx, gy)
        self.base_py = self.py
        self.collected = False
        self.bob = random.random() * 6.28

    def rect(self):
        return pygame.Rect(self.px + 6, self.py + 6, 20, 20)

    def update(self, dt):
        self.bob += dt / 300
        self.py = self.base_py + math.sin(self.bob) * 4

    def draw(self, surf, cam_x, img):
        if self.collected:
            return
        sx = self.px + 6 - cam_x
        if -20 < sx < SCREEN_W + 20:
            surf.blit(img, (sx, self.py + 6))


# ---------------------------------------------------------------------------
# Touch controls
# ---------------------------------------------------------------------------
class Touch:
    def __init__(self):
        bw, bh = 64, 64
        by = SCREEN_H - 80
        self.btns = {
            'left': pygame.Rect(10, by, bw, bh),
            'right': pygame.Rect(90, by, bw, bh),
            'jump': pygame.Rect(SCREEN_W - 90, by, bw + 10, bh + 10),
            'sprint': pygame.Rect(SCREEN_W - 170, by + 10, bw - 10, bh - 10),
        }
        self.pressed = {}
        self.labels = {'left': '<', 'right': '>', 'jump': 'A', 'sprint': 'B'}

    def event(self, ev):
        tapped = None
        if ev.type in (pygame.FINGERDOWN, pygame.MOUSEBUTTONDOWN):
            pos = self._pos(ev)
            for n, r in self.btns.items():
                if r.collidepoint(pos):
                    self.pressed[n] = True
                    tapped = n
        if ev.type in (pygame.FINGERUP, pygame.MOUSEBUTTONUP):
            self.pressed = {}
        if ev.type == pygame.FINGERMOTION:
            pos = self._pos(ev)
            self.pressed = {}
            for n, r in self.btns.items():
                if r.collidepoint(pos):
                    self.pressed[n] = True
        return tapped

    def _pos(self, ev):
        if hasattr(ev, 'x') and isinstance(ev.x, float) and ev.x <= 1.0:
            return (ev.x * SCREEN_W, ev.y * SCREEN_H)
        return getattr(ev, 'pos', (0, 0))

    def get(self, n):
        return self.pressed.get(n, False)

    def draw(self, surf, font):
        for n, r in self.btns.items():
            s = pygame.Surface((r.w, r.h), pygame.SRCALPHA)
            a = 90 if self.pressed.get(n) else 45
            s.fill((255, 255, 255, a))
            surf.blit(s, r.topleft)
            t = font.render(self.labels[n], True, (255, 255, 255))
            surf.blit(t, (r.centerx - t.get_width() // 2, r.centery - t.get_height() // 2))


# ---------------------------------------------------------------------------
# Secret Morse Code Easter Egg
# "lilgngstr" => left=dot right=dash A=next_letter B=submit
# ---------------------------------------------------------------------------
class MorseEgg:
    # "lilgngstr" in morse: each letter as dot/dash string
    TARGET = ['.-..', '..', '.-..', '--.', '-.', '--.', '...', '-', '.-.']

    def __init__(self):
        self.current_letter = ''  # dots and dashes for current letter
        self.letters = []         # completed morse letters
        self.active = False
        self.show_msg = False
        self.msg_timer = 0
        self.input_timer = 0      # reset if idle too long
        self._font = None
        self._msg_surf = None
        self._hint_surf = None

    def _build_cache(self):
        if not self._font:
            self._font = pygame.font.SysFont('arial', 16)
            big = pygame.font.SysFont('arial', 36, bold=True)
            sub = pygame.font.SysFont('arial', 20)
            # Build message surface
            self._msg_surf = pygame.Surface((SCREEN_W, SCREEN_H), pygame.SRCALPHA)
            self._msg_surf.fill((0, 0, 0, 200))
            lines = [
                (big, 'JT is special to me', (255, 180, 220), SCREEN_H // 2 - 40),
                (sub, 'lilgngstr', (255, 140, 180), SCREEN_H // 2 + 10),
            ]
            for f, txt, col, y in lines:
                t = f.render(txt, True, col)
                self._msg_surf.blit(t, (SCREEN_W // 2 - t.get_width() // 2, y))
            # Hint
            self._hint_surf = self._font.render(
                'morse: < =dot  > =dash  A=next  B=send', True, (180, 180, 200))

    def on_button(self, btn):
        """Called when a touch button is tapped: left/right/jump/sprint."""
        self._build_cache()
        if self.show_msg:
            return
        self.input_timer = 0
        if btn == 'left':
            self.current_letter += '.'
            self.active = True
        elif btn == 'right':
            self.current_letter += '-'
            self.active = True
        elif btn == 'jump' and self.current_letter:
            # Commit current letter
            self.letters.append(self.current_letter)
            self.current_letter = ''
            # Check if sequence is already wrong
            idx = len(self.letters) - 1
            if idx < len(self.TARGET) and self.letters[idx] != self.TARGET[idx]:
                self.reset()
        elif btn == 'sprint' and (self.letters or self.current_letter):
            # Submit — add current letter if any, then check
            if self.current_letter:
                self.letters.append(self.current_letter)
                self.current_letter = ''
            if self.letters == self.TARGET:
                self.show_msg = True
                self.msg_timer = 5000
            self.reset()

    def reset(self):
        self.current_letter = ''
        self.letters = []
        self.active = False

    def update(self, dt):
        if self.show_msg:
            self.msg_timer -= dt
            if self.msg_timer <= 0:
                self.show_msg = False
        if self.active:
            self.input_timer += dt
            if self.input_timer > 8000:
                self.reset()

    def draw(self, surf):
        self._build_cache()
        if self.show_msg:
            surf.blit(self._msg_surf, (0, 0))
        elif self.active:
            # Show current morse input at top
            progress = ' '.join(self.letters)
            if self.current_letter:
                progress += (' ' if progress else '') + self.current_letter + '_'
            if progress:
                t = self._font.render(progress, True, (255, 255, 150))
                surf.blit(t, (SCREEN_W // 2 - t.get_width() // 2, 4))


# ---------------------------------------------------------------------------
# Physics
# ---------------------------------------------------------------------------
def collide_tiles(player, world_tiles):
    """AABB tile collision with proper resolution."""
    player.grounded = False
    pr = player.rect()

    # Only check tiles near the player
    cx = int(player.x) // TILE
    cy_screen = int(player.y) // TILE

    for dx in range(-2, 4):
        for dy in range(-3, 4):
            tgx = cx + dx
            # Convert screen tile row to grid gy
            tgy = GRID_ROWS - 1 - (cy_screen + dy)
            key = (tgx, tgy)

            wt = world_tiles.get(key)
            if not wt or not wt.alive:
                continue

            tr = wt.rect()
            if not pr.colliderect(tr):
                continue

            ov_x = min(pr.right, tr.right) - max(pr.left, tr.left)
            ov_y = min(pr.bottom, tr.bottom) - max(pr.top, tr.top)
            if ov_x <= 0 or ov_y <= 0:
                continue

            if ov_y < ov_x:
                if pr.centery < tr.centery:
                    # Land on top
                    player.y = tr.top - player.h
                    if player.vy >= 0:
                        player.vy = 0
                        player.grounded = True
                else:
                    # Hit from below — BUMP
                    player.y = tr.bottom + 1
                    player.vy = 1
                    return ('bump', wt)
            else:
                if pr.centerx < tr.centerx:
                    player.x = tr.left - player.w
                else:
                    player.x = tr.right
                player.vx = 0

            pr = player.rect()

    return None


# ---------------------------------------------------------------------------
# HUD
# ---------------------------------------------------------------------------
def draw_hud(surf, player, level, font, small_font):
    bar = pygame.Surface((SCREEN_W, 34), pygame.SRCALPHA)
    bar.fill((0, 0, 0, 140))
    surf.blit(bar, (0, 0))

    items = [
        (f'SCORE {player.score}', (255, 255, 255), 10),
        (f'COINS {player.coins}', (255, 220, 50), 190),
        (f'JT x {player.lives}', (255, 255, 255), 360),
        (f'WORLD {level}', (255, 255, 255), 510),
    ]
    for txt, col, x in items:
        surf.blit(font.render(txt, True, col), (x, 7))

    # Health pips
    for i in range(3):
        c = (255, 50, 50) if i < player.health else (60, 60, 60)
        pygame.draw.rect(surf, c, (660 + i * 24, 8, 20, 18), border_radius=3)
        pygame.draw.rect(surf, (200, 200, 200), (660 + i * 24, 8, 20, 18), 1, border_radius=3)


# ---------------------------------------------------------------------------
# Menu screen
# ---------------------------------------------------------------------------
class MenuScreen:
    def __init__(self):
        self.sel = 0
        self.t = 0
        self.cached = False
        self.bg_surf = None  # pre-rendered static background
        self.text_cache = {}  # pre-rendered text surfaces
        self.cloud_surfs = []  # pre-rendered cloud surfaces
        self.clouds = []  # (x, y, idx) referencing cloud_surfs
        self.coin_img = None
        self.jt_img = None
        self.pipe_img = None

    def _build_cache(self):
        if self.cached:
            return
        self.cached = True

        # Fonts (created once)
        title_f = pygame.font.SysFont('arial', 52, bold=True)
        sub_f = pygame.font.SysFont('arial', 20)
        self.btn_f = pygame.font.SysFont('arial', 26, bold=True)
        hint_f = pygame.font.SysFont('arial', 14)
        ctrl_f = pygame.font.SysFont('arial', 15)

        cx = SCREEN_W // 2

        # Pre-render all text surfaces
        self.text_cache['title_shadow'] = title_f.render('SUPER JT WORLD', True, (139, 0, 0))
        self.text_cache['title_main'] = title_f.render('SUPER JT WORLD', True, (228, 40, 40))
        title_y = title_f.render('SUPER JT WORLD', True, (255, 220, 60))
        title_y.set_alpha(120)
        self.text_cache['title_glow'] = title_y
        self.text_cache['subtitle'] = sub_f.render('~ The Infinite Adventure ~', True, (255, 255, 255))
        self.text_cache['arrow'] = self.btn_f.render('>', True, (255, 255, 80))
        self.text_cache['hint1'] = ctrl_f.render('WASD / Arrows: Move  |  SPACE: Jump  |  SHIFT: Sprint', True, (255, 255, 255))
        self.text_cache['hint2'] = ctrl_f.render('Touch controls on mobile  |  ESC: Pause', True, (220, 230, 255))
        self.text_cache['version'] = hint_f.render('v1.0', True, (60, 100, 180))

        # Button text (both states)
        for label in ('START GAME', 'INFINITE MODE'):
            self.text_cache[f'btn_{label}_w'] = self.btn_f.render(label, True, (255, 255, 255))
            self.text_cache[f'btn_{label}_b'] = self.btn_f.render(label, True, (0, 0, 0))

        # Pre-render static background (sky + hills + ground + bricks)
        self.bg_surf = pygame.Surface((SCREEN_W, SCREEN_H))
        bg = self.bg_surf
        bg.fill((92, 148, 252))

        # Hills
        hill_y = SCREEN_H - TILE * 3 - 10
        for hx in [60, 350, 620]:
            pygame.draw.ellipse(bg, (58, 160, 58), (hx, hill_y, 140, 50))
            pygame.draw.ellipse(bg, (76, 185, 68), (hx + 15, hill_y + 5, 110, 35))

        # Ground tiles
        ground = _load_img('grassland/ground.png', (TILE, TILE))
        brick = _load_img('grassland/brick.png', (TILE, TILE))
        qblock = _load_img('grassland/question.png', (TILE, TILE))
        for gx in range(0, SCREEN_W, TILE):
            bg.blit(ground, (gx, SCREEN_H - TILE))
            bg.blit(ground, (gx, SCREEN_H - TILE * 2))

        row_y = SCREEN_H - TILE * 3
        for gx in range(0, SCREEN_W, TILE):
            ci = gx // TILE
            if ci % 8 == 3 or ci % 8 == 5:
                bg.blit(qblock, (gx, row_y))
            elif ci % 4 == 0:
                bg.blit(brick, (gx, row_y))

        # Pipes
        self.pipe_img = _load_img('grassland/pipe.png', (TILE * 2, TILE * 2))
        if self.pipe_img:
            bg.blit(self.pipe_img, (40, SCREEN_H - TILE * 3 - TILE + TILE))
            bg.blit(self.pipe_img, (SCREEN_W - 40 - TILE * 2, SCREEN_H - TILE * 3 - TILE + TILE))

        # Pre-render cloud surfaces (a few sizes)
        for cw in (70, 90, 110):
            ch = cw // 3
            cs = pygame.Surface((cw, ch), pygame.SRCALPHA)
            c = (255, 255, 255, 200)
            pygame.draw.ellipse(cs, c, (0, ch // 4, cw // 2, ch * 3 // 4))
            pygame.draw.ellipse(cs, c, (cw // 4, 0, cw // 2, ch))
            pygame.draw.ellipse(cs, c, (cw // 2, ch // 4, cw // 2, ch * 3 // 4))
            self.cloud_surfs.append(cs)

        # Cloud positions
        self.clouds = [(random.randint(0, SCREEN_W), random.randint(30, 160),
                        random.randint(0, 2)) for _ in range(5)]

        self.jt_img = _load_img('jt_idle.png', (TILE * 2, TILE * 2))
        self.coin_img = _load_img('coin.png', (16, 16))

        # Pre-render button backgrounds (selected + unselected for each)
        self.btn_surfs = {}
        bw, bh = 280, 46
        for label, col_dark, col_sel in [('START GAME', (220, 60, 20), (255, 90, 40)),
                                          ('INFINITE MODE', (20, 100, 180), (40, 140, 220))]:
            for sel_state, col in [(False, col_dark), (True, col_sel)]:
                s = pygame.Surface((bw, bh), pygame.SRCALPHA)
                pygame.draw.rect(s, col, (0, 0, bw, bh), border_radius=8)
                # Highlight strip
                hl = pygame.Surface((bw - 8, 6), pygame.SRCALPHA)
                hl.fill((255, 255, 255, 90 if sel_state else 50))
                s.blit(hl, (4, 3))
                # Border
                bc = (255, 255, 255) if sel_state else (255, 255, 255, 100)
                pygame.draw.rect(s, bc, (0, 0, bw, bh), 2, border_radius=8)
                self.btn_surfs[(label, sel_state)] = s

    def update(self, dt):
        self.t += dt
        self._build_cache()
        for i, (x, y, ci) in enumerate(self.clouds):
            x -= (0.3 + ci * 0.1) * dt / 16
            cw = [70, 90, 110][ci]
            if x + cw < -20:
                x = SCREEN_W + random.randint(10, 80)
                y = random.randint(30, 160)
            self.clouds[i] = (x, y, ci)

    def draw(self, surf):
        self._build_cache()
        # Blit pre-rendered background (sky + ground + hills + pipes)
        surf.blit(self.bg_surf, (0, 0))

        # Clouds (pre-rendered surfaces, just blit at position)
        for x, y, ci in self.clouds:
            surf.blit(self.cloud_surfs[ci], (int(x), int(y)))

        # JT character with bob
        if self.jt_img:
            jt_bob = math.sin(self.t / 500) * 3
            surf.blit(self.jt_img, (120, SCREEN_H - TILE * 3 - TILE * 2 + 2 + jt_bob))

        cx = SCREEN_W // 2
        tc = self.text_cache

        # Title with bounce
        bounce = math.sin(self.t / 400) * 4
        tw = tc['title_main'].get_width()
        surf.blit(tc['title_shadow'], (cx - tw // 2 + 3, 33 + bounce))
        surf.blit(tc['title_main'], (cx - tw // 2, 30 + bounce))
        surf.blit(tc['title_glow'], (cx - tw // 2 - 1, 29 + bounce))

        # Subtitle
        sw = tc['subtitle'].get_width()
        surf.blit(tc['subtitle'], (cx - sw // 2, 90))

        # Coins
        if self.coin_img:
            co = math.sin(self.t / 300) * 3
            surf.blit(self.coin_img, (cx - 180, 40 + co))
            surf.blit(self.coin_img, (cx + 165, 40 - co))

        # Buttons (pre-rendered surfaces)
        labels = ['START GAME', 'INFINITE MODE']
        btn_rects = []
        bw, bh = 280, 46
        for i, label in enumerate(labels):
            by = 125 + i * 60
            bx = cx - bw // 2
            r = pygame.Rect(bx, by, bw, bh)
            btn_rects.append(r)
            selected = i == self.sel

            # Shadow rect
            pygame.draw.rect(surf, (0, 0, 0), (bx + 3, by + 3, bw, bh), border_radius=8)

            # Pre-rendered button
            surf.blit(self.btn_surfs[(label, selected)], (bx, by))

            # Arrow
            if selected:
                ax = bx - 28 + int(math.sin(self.t / 200) * 4)
                surf.blit(tc['arrow'], (ax, by + 9))

            # Text
            tw_b = tc[f'btn_{label}_w'].get_width()
            surf.blit(tc[f'btn_{label}_b'], (cx - tw_b // 2 + 1, by + 12))
            surf.blit(tc[f'btn_{label}_w'], (cx - tw_b // 2, by + 11))

        # Hints
        hint_y = SCREEN_H - TILE * 3 - 60
        surf.blit(tc['hint1'], (cx - tc['hint1'].get_width() // 2, hint_y))
        surf.blit(tc['hint2'], (cx - tc['hint2'].get_width() // 2, hint_y + 20))

        # Version
        surf.blit(tc['version'], (SCREEN_W - 40, SCREEN_H - TILE * 2 + 5))

        return btn_rects


def draw_game_over(surf, player, level):
    overlay = pygame.Surface((SCREEN_W, SCREEN_H), pygame.SRCALPHA)
    overlay.fill((10, 5, 15, 210))
    surf.blit(overlay, (0, 0))

    cx = SCREEN_W // 2
    big_f = pygame.font.SysFont('arial', 60, bold=True)
    med_f = pygame.font.SysFont('arial', 30)
    sm_f = pygame.font.SysFont('arial', 22)
    btn_f = pygame.font.SysFont('arial', 24, bold=True)

    for off, col in [((3, 3), (80, 0, 0)), ((0, 0), (255, 50, 50))]:
        t = big_f.render('GAME OVER', True, col)
        surf.blit(t, (cx - t.get_width() // 2 + off[0], 90 + off[1]))

    t = med_f.render(f'Final Score: {player.score}', True, (255, 255, 255))
    surf.blit(t, (cx - t.get_width() // 2, 175))
    t = sm_f.render(f'Reached World {level}', True, (200, 200, 220))
    surf.blit(t, (cx - t.get_width() // 2, 220))

    btns = []
    for i, (label, col) in enumerate([('TRY AGAIN', (100, 255, 100)), ('MAIN MENU', (255, 150, 150))]):
        by = 280 + i * 56
        bw, bh = 240, 44
        bx = cx - bw // 2
        r = pygame.Rect(bx, by, bw, bh)
        btns.append(r)
        bg = pygame.Surface((bw, bh), pygame.SRCALPHA)
        bg.fill((40, 40, 50, 200))
        surf.blit(bg, (bx, by))
        pygame.draw.rect(surf, col, r, 2, border_radius=5)
        t = btn_f.render(label, True, col)
        surf.blit(t, (cx - t.get_width() // 2, by + 9))

    h = pygame.font.SysFont('arial', 15).render('ENTER: Retry  |  ESC: Menu', True, (140, 140, 160))
    surf.blit(h, (cx - h.get_width() // 2, 420))
    return btns


# ---------------------------------------------------------------------------
# Main loop
# ---------------------------------------------------------------------------
async def main():
    pygame.init()
    pygame.mixer.init(22050, -16, 1, 512)
    screen = pygame.display.set_mode((SCREEN_W, SCREEN_H))
    pygame.display.set_caption('Super JT World')
    clock = pygame.time.Clock()

    assets = Assets()
    touch = Touch()
    morse_egg = MorseEgg()
    level_gen = LevelGen()
    menu = MenuScreen()

    hud_font = pygame.font.SysFont('arial', 20, bold=True)
    small_font = pygame.font.SysFont('arial', 14)
    touch_font = pygame.font.SysFont('arial', 20, bold=True)
    announce_font = pygame.font.SysFont('arial', 42, bold=True)

    # Pre-render pause overlay and text
    pause_overlay = pygame.Surface((SCREEN_W, SCREEN_H), pygame.SRCALPHA)
    pause_overlay.fill((10, 10, 20, 190))
    _pf = pygame.font.SysFont('arial', 56, bold=True)
    pause_text = _pf.render('PAUSED', True, (255, 255, 255))
    _sf = pygame.font.SysFont('arial', 20)
    pause_hint = _sf.render('Press ESC or ENTER to resume', True, (200, 200, 220))

    state = 'menu'
    infinite = False
    cur_level = 1

    player = Player(assets)
    world_tiles = {}    # (gx,gy) -> WorldTile
    enemies = []
    coin_objs = []
    pop_items = []      # items popping out of mystery boxes
    mystery_map = {}    # (gx,gy) -> reward
    cam_x = 0.0
    flag_gx = 0
    theme = 'grassland'
    announce = ''
    announce_t = 0

    def load_level(lvl):
        nonlocal world_tiles, enemies, coin_objs, pop_items, mystery_map
        nonlocal cam_x, flag_gx, theme, announce, announce_t

        data = level_gen.generate(lvl)
        theme = data['theme']
        tt = assets.tiles[theme]
        flag_gx = data['flag_gx']

        world_tiles = {}
        for gx, gy, ttype in data['tiles']:
            world_tiles[(gx, gy)] = WorldTile(gx, gy, ttype, tt)

        mystery_map = {}
        for gx, gy, reward in data['mystery']:
            mystery_map[(gx, gy)] = reward

        enemies = [Enemy(gx, gy, et, assets) for gx, gy, et in data['enemies']]
        coin_objs = [Coin(gx, gy) for gx, gy in data['coins']]
        pop_items = []

        player.x, player.y = 100, 200
        player.vx = player.vy = 0
        player.alive = True
        player.grounded = False
        player.inv = False
        player.inv_t = 0
        cam_x = 0

        announce = f'WORLD {lvl} - {theme.upper()}'
        announce_t = 2500

        is_boss = data['is_boss']
        track = 'boss' if is_boss else ('underground' if theme in ('underground', 'haunted', 'factory', 'lava') else 'theme')
        assets.music(track)

    running = True
    while running:
        dt = clock.tick(FPS)

        for ev in pygame.event.get():
            if ev.type == pygame.QUIT:
                running = False
                break
            tapped_btn = touch.event(ev)
            if tapped_btn:
                morse_egg.on_button(tapped_btn)

            if ev.type == pygame.KEYDOWN:
                if state == 'menu':
                    if ev.key in (pygame.K_UP, pygame.K_w):
                        menu.sel = (menu.sel - 1) % 2
                        assets.play('select')
                    elif ev.key in (pygame.K_DOWN, pygame.K_s):
                        menu.sel = (menu.sel + 1) % 2
                        assets.play('select')
                    elif ev.key in (pygame.K_RETURN, pygame.K_SPACE):
                        assets.play('select')
                        infinite = menu.sel == 1
                        cur_level = 1
                        player.reset()
                        load_level(cur_level)
                        state = 'playing'
                elif state == 'playing':
                    if ev.key == pygame.K_ESCAPE:
                        state = 'paused'
                        assets.play('pause')
                elif state == 'paused':
                    if ev.key in (pygame.K_ESCAPE, pygame.K_RETURN):
                        state = 'playing'
                elif state == 'game_over':
                    if ev.key in (pygame.K_RETURN, pygame.K_SPACE):
                        cur_level = 1; player.reset(); load_level(cur_level); state = 'playing'
                    elif ev.key == pygame.K_ESCAPE:
                        state = 'menu'

            # Handle both mouse and touch for UI buttons
            if ev.type in (pygame.MOUSEBUTTONDOWN, pygame.FINGERDOWN):
                if ev.type == pygame.FINGERDOWN:
                    mx = int(ev.x * SCREEN_W)
                    my = int(ev.y * SCREEN_H)
                else:
                    mx, my = ev.pos
                if state == 'menu':
                    bw, bh = 280, 46
                    bx = SCREEN_W // 2 - bw // 2
                    for i in range(2):
                        by = 125 + i * 60
                        r = pygame.Rect(bx, by, bw, bh)
                        if r.collidepoint(mx, my):
                            assets.play('select')
                            infinite = i == 1
                            cur_level = 1; player.reset(); load_level(cur_level); state = 'playing'
                elif state == 'game_over':
                    retry_r = pygame.Rect(SCREEN_W // 2 - 120, 280, 240, 44)
                    menu_r = pygame.Rect(SCREEN_W // 2 - 120, 336, 240, 44)
                    if retry_r.collidepoint(mx, my):
                        cur_level = 1; player.reset(); load_level(cur_level); state = 'playing'
                    elif menu_r.collidepoint(mx, my):
                        state = 'menu'

        if not running:
            break

        # ===== UPDATE =====
        morse_egg.update(dt)

        if state == 'menu':
            menu.update(dt)

        elif state == 'playing':
            keys = pygame.key.get_pressed()
            player.update(keys, touch, dt)

            # Tile updates (bump animations)
            for wt in world_tiles.values():
                wt.update(dt)

            if player.alive:
                # Tile collision
                result = collide_tiles(player, world_tiles)

                if result and result[0] == 'bump':
                    wt = result[1]
                    gx, gy = wt.gx, wt.gy

                    if wt.ttype == 'question' and not wt.used:
                        # Mystery box hit! Pop out item
                        wt.used = True
                        wt.bump()
                        reward = mystery_map.get((gx, gy), 'coin')
                        pop_items.append(PopItem(wt.px, wt.py, reward, assets))
                        if reward == 'coin':
                            player.collect_coin()
                        assets.play('coin')

                    elif wt.ttype == 'brick':
                        if player.big:
                            wt.start_break()
                            assets.play('brick_break')
                        else:
                            wt.bump()

                    elif wt.ttype == 'question' and wt.used:
                        wt.bump()

                # Camera
                target = player.x - SCREEN_W // 3
                cam_x += (target - cam_x) * 0.08
                level_w = level_gen.generate(cur_level)['width_gx'] * TILE
                cam_x = max(0, min(cam_x, level_w - SCREEN_W))

                # Enemies
                for e in enemies:
                    e.active = abs(e.px - player.x) < SCREEN_W
                    e.update(dt)
                    if not e.alive:
                        continue
                    pr = player.rect()
                    er = e.rect()
                    if pr.colliderect(er):
                        if player.vy > 0 and pr.bottom - er.top < 18:
                            player.score += e.stomp()
                            player.vy = JUMP_FORCE * 0.55
                            assets.play('stomp')
                        elif player.star:
                            e.stomp()
                            player.score += 200
                        else:
                            player.hit()

                # Coins
                pr = player.rect()
                for c in coin_objs:
                    if c.collected:
                        continue
                    c.update(dt)
                    if pr.colliderect(c.rect()):
                        c.collected = True
                        player.collect_coin()

                # Pop items (from mystery boxes)
                for pi in pop_items:
                    pi.update(dt)
                    if not pi.is_coin and pi.alive and not pi.rising:
                        if pr.colliderect(pi.rect()):
                            pi.alive = False
                            player.collect_powerup(pi.reward)

                pop_items = [p for p in pop_items if p.alive or (p.is_coin and p.timer < 500)]

                # Flag
                fpx, _ = grid_to_px(flag_gx, 0)
                if player.x >= fpx:
                    assets.play('level_complete')
                    player.score += 1000
                    cur_level += 1
                    load_level(cur_level)

            else:
                if player.dead_t > 2000:
                    if player.lives > 0:
                        player.alive = True
                        player.health = 3
                        player.x, player.y = 100, 200
                        player.vx = player.vy = 0
                        player.inv = True
                        player.inv_t = 2000
                    else:
                        state = 'game_over'

            if announce_t > 0:
                announce_t -= dt

        # ===== DRAW =====
        if state == 'menu':
            menu.draw(screen)

        elif state in ('playing', 'paused'):
            screen.fill(SKY.get(theme, (92, 148, 252)))

            # Parallax BG
            bg = assets.bgs.get(theme)
            if bg:
                bx = int(-cam_x * 0.3) % SCREEN_W
                screen.blit(bg, (bx - SCREEN_W, 0))
                screen.blit(bg, (bx, 0))

            # Tiles
            for wt in world_tiles.values():
                wt.draw(screen, cam_x)

            # Flag
            fpx, _ = grid_to_px(flag_gx, 0)
            fx = fpx - cam_x
            pygame.draw.rect(screen, (200, 200, 200), (fx, 60, 6, SCREEN_H - 60))
            # Flag banner
            pts = [(fx + 6, 60), (fx + 40, 72), (fx + 6, 84)]
            pygame.draw.polygon(screen, (255, 50, 50), pts)

            # Coins
            for c in coin_objs:
                c.draw(screen, cam_x, assets.coin_img)

            # Pop items
            for pi in pop_items:
                pi.draw(screen, cam_x)

            # Enemies
            for e in enemies:
                e.draw(screen, cam_x)

            # Player
            player.draw(screen, cam_x)

            # HUD
            draw_hud(screen, player, cur_level, hud_font, small_font)

            # Announcement
            if announce_t > 0:
                at = announce_font.render(announce, True, (255, 255, 255))
                ash = announce_font.render(announce, True, (0, 0, 0))
                screen.blit(ash, (SCREEN_W // 2 - at.get_width() // 2 + 2, SCREEN_H // 3 + 2))
                screen.blit(at, (SCREEN_W // 2 - at.get_width() // 2, SCREEN_H // 3))

            # Touch
            touch.draw(screen, touch_font)

            # Pause overlay
            if state == 'paused':
                screen.blit(pause_overlay, (0, 0))
                screen.blit(pause_text, (SCREEN_W // 2 - pause_text.get_width() // 2, SCREEN_H // 2 - 50))
                screen.blit(pause_hint, (SCREEN_W // 2 - pause_hint.get_width() // 2, SCREEN_H // 2 + 20))

        elif state == 'game_over':
            screen.fill(SKY.get(theme, (30, 20, 40)))
            draw_game_over(screen, player, cur_level)

        morse_egg.draw(screen)
        pygame.display.flip()
        await asyncio.sleep(0)

    pygame.quit()


if __name__ == '__main__':
    asyncio.run(main())
