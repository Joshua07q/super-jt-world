"""Generate all game assets — PNG sprites, WAV sounds, and music."""
import os
import math
import struct
import wave
import random
from PIL import Image, ImageDraw

ASSET_DIR = os.path.join(os.path.dirname(__file__), 'assets')
TEX_DIR = os.path.join(ASSET_DIR, 'textures')
SFX_DIR = os.path.join(ASSET_DIR, 'sounds')
MUS_DIR = os.path.join(ASSET_DIR, 'music')

SAMPLE_RATE = 22050


def ensure_dirs():
    for d in [TEX_DIR, SFX_DIR, MUS_DIR]:
        os.makedirs(d, exist_ok=True)
    for theme in THEMES:
        os.makedirs(os.path.join(TEX_DIR, theme), exist_ok=True)


# ============================================================
# COLOR PALETTES
# ============================================================

THEMES = [
    'grassland', 'underground', 'sky', 'desert', 'snow',
    'lava', 'ocean', 'factory', 'haunted', 'crystal',
]

THEME_PALETTES = {
    'grassland': {
        'ground_top': (100, 200, 60), 'ground': (139, 90, 43), 'ground_dark': (100, 65, 30),
        'brick': (200, 100, 50), 'brick_line': (160, 75, 35),
        'question': (255, 200, 50), 'question_border': (180, 140, 30),
        'pipe': (50, 180, 50), 'pipe_dark': (20, 140, 20), 'pipe_light': (90, 220, 90),
        'sky': (92, 148, 252),
    },
    'underground': {
        'ground_top': (80, 80, 100), 'ground': (50, 50, 70), 'ground_dark': (35, 35, 50),
        'brick': (100, 100, 130), 'brick_line': (70, 70, 100),
        'question': (200, 180, 80), 'question_border': (150, 130, 50),
        'pipe': (40, 140, 40), 'pipe_dark': (20, 100, 20), 'pipe_light': (70, 180, 70),
        'sky': (20, 15, 30),
    },
    'sky': {
        'ground_top': (200, 220, 255), 'ground': (170, 200, 240), 'ground_dark': (140, 170, 210),
        'brick': (220, 220, 240), 'brick_line': (180, 180, 210),
        'question': (255, 220, 100), 'question_border': (200, 170, 60),
        'pipe': (100, 200, 255), 'pipe_dark': (60, 160, 220), 'pipe_light': (140, 230, 255),
        'sky': (135, 200, 255),
    },
    'desert': {
        'ground_top': (230, 200, 130), 'ground': (210, 175, 100), 'ground_dark': (180, 145, 75),
        'brick': (220, 190, 120), 'brick_line': (190, 160, 90),
        'question': (255, 210, 60), 'question_border': (200, 160, 30),
        'pipe': (180, 160, 60), 'pipe_dark': (140, 120, 30), 'pipe_light': (220, 200, 100),
        'sky': (255, 200, 120),
    },
    'snow': {
        'ground_top': (240, 245, 255), 'ground': (200, 210, 230), 'ground_dark': (170, 180, 200),
        'brick': (210, 220, 240), 'brick_line': (180, 190, 210),
        'question': (255, 230, 100), 'question_border': (200, 180, 60),
        'pipe': (100, 180, 200), 'pipe_dark': (60, 140, 160), 'pipe_light': (140, 220, 240),
        'sky': (200, 215, 240),
    },
    'lava': {
        'ground_top': (80, 30, 30), 'ground': (60, 20, 20), 'ground_dark': (40, 10, 10),
        'brick': (120, 40, 30), 'brick_line': (90, 30, 20),
        'question': (255, 150, 50), 'question_border': (200, 100, 20),
        'pipe': (150, 60, 30), 'pipe_dark': (110, 30, 10), 'pipe_light': (190, 90, 50),
        'sky': (60, 15, 10),
    },
    'ocean': {
        'ground_top': (60, 140, 160), 'ground': (40, 100, 130), 'ground_dark': (30, 70, 100),
        'brick': (80, 150, 170), 'brick_line': (50, 120, 140),
        'question': (255, 220, 80), 'question_border': (200, 170, 40),
        'pipe': (40, 160, 120), 'pipe_dark': (20, 120, 80), 'pipe_light': (80, 200, 160),
        'sky': (30, 80, 140),
    },
    'factory': {
        'ground_top': (120, 120, 130), 'ground': (90, 90, 100), 'ground_dark': (60, 60, 70),
        'brick': (140, 140, 150), 'brick_line': (100, 100, 110),
        'question': (255, 200, 50), 'question_border': (200, 150, 20),
        'pipe': (160, 160, 60), 'pipe_dark': (120, 120, 30), 'pipe_light': (200, 200, 100),
        'sky': (60, 60, 75),
    },
    'haunted': {
        'ground_top': (70, 60, 90), 'ground': (50, 40, 70), 'ground_dark': (35, 25, 50),
        'brick': (90, 75, 110), 'brick_line': (60, 50, 80),
        'question': (180, 150, 220), 'question_border': (130, 100, 170),
        'pipe': (80, 100, 60), 'pipe_dark': (50, 70, 30), 'pipe_light': (110, 130, 90),
        'sky': (30, 20, 50),
    },
    'crystal': {
        'ground_top': (180, 200, 255), 'ground': (140, 160, 220), 'ground_dark': (100, 120, 180),
        'brick': (200, 210, 255), 'brick_line': (160, 170, 220),
        'question': (255, 240, 200), 'question_border': (200, 190, 150),
        'pipe': (150, 220, 255), 'pipe_dark': (110, 180, 220), 'pipe_light': (190, 240, 255),
        'sky': (40, 30, 80),
    },
}


# ============================================================
# SPRITE GENERATION
# ============================================================

def make_jt_idle(size=32):
    """JT idle — purple-haired heroine."""
    img = Image.new('RGBA', (size, size), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    cx = size // 2

    # Boots
    d.rectangle([cx-5, size-5, cx-2, size-1], fill=(100, 50, 30))
    d.rectangle([cx+1, size-5, cx+4, size-1], fill=(100, 50, 30))

    # Pants
    d.rectangle([cx-5, size-11, cx+4, size-6], fill=(60, 60, 180))
    # Leg gap
    for y in range(size-9, size-6):
        img.putpixel((cx, y), (0, 0, 0, 0))

    # Belt
    d.rectangle([cx-5, size-12, cx+4, size-11], fill=(220, 180, 40))

    # Shirt
    d.rectangle([cx-6, size-19, cx+5, size-12], fill=(255, 80, 120))

    # Arms (skin)
    d.rectangle([cx-8, size-18, cx-6, size-14], fill=(255, 200, 160))
    d.rectangle([cx+6, size-18, cx+8, size-14], fill=(255, 200, 160))

    # Neck
    d.rectangle([cx-2, size-20, cx+1, size-19], fill=(255, 200, 160))

    # Head
    d.ellipse([cx-6, size-29, cx+5, size-20], fill=(255, 200, 160))

    # Eyes
    d.rectangle([cx-4, size-26, cx-3, size-24], fill=(40, 40, 80))
    d.rectangle([cx+2, size-26, cx+3, size-24], fill=(40, 40, 80))
    # Eye whites
    img.putpixel((cx-2, size-25), (255, 255, 255, 255))
    img.putpixel((cx+4, size-25), (255, 255, 255, 255))

    # Mouth
    d.rectangle([cx-1, size-23, cx+1, size-22], fill=(220, 100, 100))

    # Hair
    d.ellipse([cx-7, size-32, cx+6, size-25], fill=(180, 50, 220))
    # Side hair
    d.rectangle([cx-8, size-28, cx-6, size-22], fill=(180, 50, 220))
    d.rectangle([cx+6, size-28, cx+8, size-22], fill=(180, 50, 220))
    # Flowing hair strands
    d.rectangle([cx-9, size-26, cx-7, size-16], fill=(180, 50, 220))
    d.rectangle([cx+7, size-26, cx+9, size-16], fill=(180, 50, 220))

    return img


def make_jt_run(size=32, frame=0):
    """JT run frame — legs alternate."""
    img = make_jt_idle(size)
    d = ImageDraw.Draw(img)
    cx = size // 2

    # Clear boots area and redraw with offset
    for y in range(size-5, size):
        for x in range(cx-6, cx+6):
            if 0 <= x < size:
                img.putpixel((x, y), (0, 0, 0, 0))

    offsets = [(-2, 2), (0, 3), (2, -1), (3, -2)]
    lo, ro = offsets[frame % 4]

    d.rectangle([cx-4+lo, size-5, cx-1+lo, size-1], fill=(100, 50, 30))
    d.rectangle([cx+1+ro, size-5, cx+4+ro, size-1], fill=(100, 50, 30))

    # Add motion hair trail
    trail = frame % 3
    for dy in range(3):
        hx = cx + 8 + trail
        hy = size - 24 + dy * 2
        if 0 <= hx < size and 0 <= hy < size:
            img.putpixel((hx, hy), (180, 50, 220, 255))
            if hx + 1 < size:
                img.putpixel((hx+1, hy), (180, 50, 220, 200))

    return img


def make_jt_jump(size=32):
    """JT jumping — arms up."""
    img = Image.new('RGBA', (size, size), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    cx = size // 2

    # Boots tucked
    d.rectangle([cx-5, size-4, cx-1, size-1], fill=(100, 50, 30))
    d.rectangle([cx+1, size-4, cx+5, size-1], fill=(100, 50, 30))

    # Pants
    d.rectangle([cx-5, size-9, cx+4, size-5], fill=(60, 60, 180))

    # Shirt
    d.rectangle([cx-6, size-17, cx+5, size-10], fill=(255, 80, 120))

    # Arms UP
    d.rectangle([cx-9, size-23, cx-7, size-15], fill=(255, 200, 160))
    d.rectangle([cx+7, size-23, cx+9, size-15], fill=(255, 200, 160))

    # Neck
    d.rectangle([cx-2, size-18, cx+1, size-17], fill=(255, 200, 160))

    # Head
    d.ellipse([cx-6, size-27, cx+5, size-18], fill=(255, 200, 160))

    # Eyes looking up
    d.rectangle([cx-4, size-25, cx-3, size-23], fill=(40, 40, 80))
    d.rectangle([cx+2, size-25, cx+3, size-23], fill=(40, 40, 80))

    # Hair flowing up
    d.ellipse([cx-7, size-32, cx+6, size-24], fill=(180, 50, 220))
    d.rectangle([cx-8, size-28, cx-6, size-20], fill=(180, 50, 220))
    d.rectangle([cx+6, size-28, cx+8, size-20], fill=(180, 50, 220))

    return img


def make_goomba(size=32):
    img = Image.new('RGBA', (size, size), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    cx = size // 2

    # Body (mushroom shape)
    d.ellipse([cx-10, size-22, cx+10, size-6], fill=(160, 90, 40))
    d.rectangle([cx-6, size-8, cx+6, size-1], fill=(100, 55, 25))

    # Feet
    d.ellipse([cx-9, size-4, cx-3, size-1], fill=(100, 55, 25))
    d.ellipse([cx+3, size-4, cx+9, size-1], fill=(100, 55, 25))

    # Eyes (angry)
    d.ellipse([cx-7, size-18, cx-2, size-13], fill=(255, 255, 255))
    d.ellipse([cx+2, size-18, cx+7, size-13], fill=(255, 255, 255))
    d.ellipse([cx-5, size-17, cx-3, size-14], fill=(20, 20, 20))
    d.ellipse([cx+3, size-17, cx+5, size-14], fill=(20, 20, 20))

    # Eyebrows (angry)
    d.line([cx-8, size-19, cx-2, size-17], fill=(80, 40, 20), width=2)
    d.line([cx+2, size-17, cx+8, size-19], fill=(80, 40, 20), width=2)

    return img


def make_koopa(size=32):
    img = Image.new('RGBA', (size, size), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    cx = size // 2

    # Feet
    d.ellipse([cx-7, size-4, cx-1, size-1], fill=(255, 220, 100))
    d.ellipse([cx+1, size-4, cx+7, size-1], fill=(255, 220, 100))

    # Shell
    d.ellipse([cx-9, size-18, cx+9, size-5], fill=(30, 140, 30))
    d.ellipse([cx-7, size-16, cx+7, size-7], fill=(50, 180, 50))
    # Shell pattern
    d.line([cx, size-17, cx, size-6], fill=(20, 100, 20), width=2)
    d.line([cx-5, size-12, cx+5, size-12], fill=(20, 100, 20), width=1)

    # Head
    d.ellipse([cx-5, size-26, cx+5, size-17], fill=(50, 180, 50))

    # Eyes
    d.ellipse([cx, size-24, cx+4, size-20], fill=(255, 255, 255))
    d.ellipse([cx+2, size-23, cx+4, size-21], fill=(20, 20, 20))

    return img


def make_flying_enemy(size=32):
    img = Image.new('RGBA', (size, size), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    cx, cy = size // 2, size // 2

    # Body
    d.ellipse([cx-6, cy-5, cx+6, cy+5], fill=(180, 60, 60))

    # Wings
    d.polygon([(cx-6, cy-2), (cx-13, cy-8), (cx-10, cy+1)], fill=(255, 200, 200))
    d.polygon([(cx+6, cy-2), (cx+13, cy-8), (cx+10, cy+1)], fill=(255, 200, 200))

    # Eyes
    d.ellipse([cx-4, cy-3, cx-1, cy+1], fill=(255, 255, 0))
    d.ellipse([cx+1, cy-3, cx+4, cy+1], fill=(255, 255, 0))
    d.ellipse([cx-3, cy-2, cx-2, cy], fill=(20, 20, 20))
    d.ellipse([cx+2, cy-2, cx+3, cy], fill=(20, 20, 20))

    # Mouth
    d.arc([cx-3, cy+1, cx+3, cy+4], 0, 180, fill=(100, 20, 20), width=1)

    return img


def make_boss(size=64):
    img = Image.new('RGBA', (size, size), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    cx = size // 2

    # Body
    d.ellipse([cx-18, size-38, cx+18, size-4], fill=(50, 120, 50))

    # Shell on back
    d.ellipse([cx-15, size-35, cx+15, size-12], fill=(120, 80, 30))
    d.ellipse([cx-12, size-32, cx+12, size-15], fill=(160, 110, 50))

    # Spikes
    for i in range(-2, 3):
        sx = cx + i * 7
        d.polygon([(sx-3, size-33), (sx, size-42), (sx+3, size-33)], fill=(220, 200, 160))

    # Head
    d.ellipse([cx-12, size-52, cx+12, size-36], fill=(50, 120, 50))

    # Horns
    d.polygon([(cx-10, size-48), (cx-14, size-58), (cx-6, size-48)], fill=(220, 200, 160))
    d.polygon([(cx+10, size-48), (cx+14, size-58), (cx+6, size-48)], fill=(220, 200, 160))

    # Eyes (menacing red)
    d.ellipse([cx-8, size-48, cx-2, size-42], fill=(255, 255, 200))
    d.ellipse([cx+2, size-48, cx+8, size-42], fill=(255, 255, 200))
    d.ellipse([cx-6, size-47, cx-3, size-43], fill=(255, 50, 50))
    d.ellipse([cx+3, size-47, cx+6, size-43], fill=(255, 50, 50))

    # Mouth
    d.arc([cx-8, size-42, cx+8, size-36], 0, 180, fill=(200, 50, 30), width=2)

    # Feet/claws
    d.ellipse([cx-16, size-8, cx-6, size-1], fill=(50, 120, 50))
    d.ellipse([cx+6, size-8, cx+16, size-1], fill=(50, 120, 50))

    return img


def make_mushroom(size=32):
    img = Image.new('RGBA', (size, size), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    cx = size // 2

    # Stem
    d.rectangle([cx-4, size-10, cx+4, size-1], fill=(240, 220, 180))

    # Cap
    d.ellipse([cx-10, size-22, cx+10, size-8], fill=(255, 50, 50))

    # White dots on cap
    d.ellipse([cx-7, size-20, cx-3, size-16], fill=(255, 255, 255))
    d.ellipse([cx+3, size-20, cx+7, size-16], fill=(255, 255, 255))
    d.ellipse([cx-2, size-22, cx+2, size-18], fill=(255, 255, 255))

    # Eyes on stem
    d.ellipse([cx-3, size-8, cx-1, size-5], fill=(20, 20, 20))
    d.ellipse([cx+1, size-8, cx+3, size-5], fill=(20, 20, 20))

    return img


def make_star(size=32):
    img = Image.new('RGBA', (size, size), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    cx, cy = size // 2, size // 2

    # 5-pointed star
    points = []
    for i in range(10):
        angle = math.pi / 2 + i * math.pi / 5
        r = 12 if i % 2 == 0 else 5
        points.append((cx + r * math.cos(angle), cy - r * math.sin(angle)))

    d.polygon(points, fill=(255, 220, 50))
    # Inner bright
    inner_pts = []
    for i in range(10):
        angle = math.pi / 2 + i * math.pi / 5
        r = 7 if i % 2 == 0 else 3
        inner_pts.append((cx + r * math.cos(angle), cy - r * math.sin(angle)))
    d.polygon(inner_pts, fill=(255, 255, 150))

    # Eyes
    d.ellipse([cx-4, cy-2, cx-1, cy+1], fill=(20, 20, 20))
    d.ellipse([cx+1, cy-2, cx+4, cy+1], fill=(20, 20, 20))

    return img


def make_fire_flower(size=32):
    img = Image.new('RGBA', (size, size), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    cx = size // 2

    # Stem
    d.rectangle([cx-1, size-12, cx+1, size-1], fill=(50, 160, 50))
    # Leaves
    d.ellipse([cx-6, size-8, cx-1, size-4], fill=(50, 180, 50))
    d.ellipse([cx+1, size-8, cx+6, size-4], fill=(50, 180, 50))

    # Petals
    petal_color = (255, 100, 50)
    center = (cx, size - 18)
    for angle in range(0, 360, 45):
        rad = math.radians(angle)
        px = center[0] + int(5 * math.cos(rad))
        py = center[1] + int(5 * math.sin(rad))
        d.ellipse([px-3, py-3, px+3, py+3], fill=petal_color)

    # Center
    d.ellipse([cx-3, size-21, cx+3, size-15], fill=(255, 220, 50))

    return img


def make_feather(size=32):
    img = Image.new('RGBA', (size, size), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)

    # Quill
    d.line([(size//2+4, 2), (size//2-4, size-2)], fill=(180, 140, 100), width=2)

    # Barbs
    for y in range(4, size-4, 2):
        t = (y - 4) / (size - 8)
        qx = size//2 + 4 - int(8 * t)
        spread = int(4 + 4 * math.sin(t * math.pi))
        d.line([(qx-spread, y), (qx, y)], fill=(200, 230, 255), width=1)
        d.line([(qx, y), (qx+spread, y)], fill=(200, 230, 255), width=1)

    return img


def make_coin(size=32):
    img = Image.new('RGBA', (size, size), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    cx, cy = size // 2, size // 2

    # Gold coin circle
    d.ellipse([cx-8, cy-8, cx+8, cy+8], fill=(255, 200, 50), outline=(200, 150, 30), width=2)

    # Inner circle
    d.ellipse([cx-5, cy-5, cx+5, cy+5], fill=(255, 220, 80))

    # $ symbol approximation
    d.line([(cx, cy-4), (cx, cy+4)], fill=(200, 150, 30), width=2)
    d.arc([cx-3, cy-4, cx+3, cy], 180, 0, fill=(200, 150, 30), width=1)
    d.arc([cx-3, cy, cx+3, cy+4], 0, 180, fill=(200, 150, 30), width=1)

    return img


def make_ground_tile(palette, size=32):
    img = Image.new('RGBA', (size, size), palette['ground'] + (255,))
    d = ImageDraw.Draw(img)

    # Top grass layer
    d.rectangle([0, 0, size-1, 5], fill=palette['ground_top'] + (255,))

    # Texture noise
    rng = random.Random(42)
    for _ in range(size * 2):
        x = rng.randint(0, size-1)
        y = rng.randint(6, size-1)
        img.putpixel((x, y), palette['ground_dark'] + (255,))

    return img


def make_brick_tile(palette, size=32):
    img = Image.new('RGBA', (size, size), palette['brick'] + (255,))
    d = ImageDraw.Draw(img)

    # Mortar lines
    mortar = palette['brick_line'] + (255,)
    for y in range(0, size, 8):
        d.line([(0, y), (size-1, y)], fill=mortar, width=1)

    # Vertical mortar (offset per row)
    for row in range(size // 8):
        offset = 0 if row % 2 == 0 else size // 2
        d.line([(offset, row*8), (offset, row*8+7)], fill=mortar, width=1)
        d.line([((offset + size//2) % size, row*8), ((offset + size//2) % size, row*8+7)], fill=mortar, width=1)

    return img


def make_question_tile(palette, size=32):
    img = Image.new('RGBA', (size, size), palette['question'] + (255,))
    d = ImageDraw.Draw(img)

    # Border
    border = palette['question_border'] + (255,)
    d.rectangle([0, 0, size-1, size-1], outline=border, width=2)

    # Inner bevel highlight
    d.rectangle([2, 2, size-3, size-3], outline=(255, 230, 120, 255), width=1)

    # Question mark "?"
    dark = (180, 100, 20, 255)
    d.arc([size//2-5, 6, size//2+5, 16], 180, 0, fill=dark, width=2)
    d.line([(size//2+5, 11), (size//2+5, 14)], fill=dark, width=2)
    d.line([(size//2+5, 14), (size//2, 18)], fill=dark, width=2)
    d.line([(size//2, 18), (size//2, 22)], fill=dark, width=2)
    # Dot
    d.ellipse([size//2-1, 24, size//2+1, 26], fill=dark)

    return img


def make_pipe_tile(palette, size=32):
    img = Image.new('RGBA', (size, size), palette['pipe'] + (255,))
    d = ImageDraw.Draw(img)

    # Left dark edge
    d.rectangle([0, 0, 4, size-1], fill=palette['pipe_dark'] + (255,))
    # Right dark edge
    d.rectangle([size-5, 0, size-1, size-1], fill=palette['pipe_dark'] + (255,))
    # Left highlight
    d.rectangle([5, 0, 9, size-1], fill=palette['pipe_light'] + (255,))

    return img


def make_background(palette, width=128, height=128):
    sky = palette['sky']
    img = Image.new('RGBA', (width, height), (0, 0, 0, 255))
    d = ImageDraw.Draw(img)

    # Gradient sky
    for y in range(height):
        t = y / height
        r = int(sky[0] * (1.0 - 0.3 * t))
        g = int(sky[1] * (1.0 - 0.3 * t))
        b = int(sky[2] * (1.0 - 0.3 * t))
        d.line([(0, y), (width-1, y)], fill=(min(r, 255), min(g, 255), min(b, 255), 255))

    # Clouds or stars
    rng = random.Random(12345)
    bright = sky[0] + sky[1] + sky[2]
    if bright > 300:
        # Light theme — clouds
        for _ in range(4):
            cx = rng.randint(10, width-10)
            cy = rng.randint(10, height//2)
            d.ellipse([cx-12, cy-4, cx+12, cy+4], fill=(255, 255, 255, 120))
            d.ellipse([cx-6, cy-7, cx+8, cy+2], fill=(255, 255, 255, 140))
    else:
        # Dark theme — stars
        for _ in range(30):
            sx = rng.randint(0, width-1)
            sy = rng.randint(0, height-1)
            img.putpixel((sx, sy), (255, 255, 255, 200))

    return img


# ============================================================
# SOUND GENERATION (synthesized chiptune-style WAV)
# ============================================================

def write_wav(filepath, samples, sample_rate=SAMPLE_RATE):
    """Write a list of float samples (-1 to 1) as a 16-bit mono WAV."""
    with wave.open(filepath, 'w') as wf:
        wf.setnchannels(1)
        wf.setsampwidth(2)
        wf.setframerate(sample_rate)
        data = b''
        for s in samples:
            s = max(-1.0, min(1.0, s))
            data += struct.pack('<h', int(s * 32767 * 0.7))
        wf.writeframes(data)


def sine_wave(freq, duration, volume=0.5, sr=SAMPLE_RATE):
    n = int(sr * duration)
    return [volume * math.sin(2 * math.pi * freq * i / sr) for i in range(n)]


def square_wave(freq, duration, volume=0.3, sr=SAMPLE_RATE):
    n = int(sr * duration)
    return [volume * (1 if math.sin(2 * math.pi * freq * i / sr) >= 0 else -1) for i in range(n)]


def triangle_wave(freq, duration, volume=0.4, sr=SAMPLE_RATE):
    n = int(sr * duration)
    samples = []
    for i in range(n):
        t = (freq * i / sr) % 1.0
        samples.append(volume * (4 * abs(t - 0.5) - 1))
    return samples


def noise(duration, volume=0.2, sr=SAMPLE_RATE):
    n = int(sr * duration)
    return [volume * (random.random() * 2 - 1) for _ in range(n)]


def apply_envelope(samples, attack=0.01, decay=0.05, sustain=0.7, release=0.1):
    """ADSR envelope."""
    n = len(samples)
    sr = SAMPLE_RATE
    a = int(attack * sr)
    dc = int(decay * sr)
    r = int(release * sr)
    result = []
    for i, s in enumerate(samples):
        if i < a:
            env = i / max(a, 1)
        elif i < a + dc:
            env = 1.0 - (1.0 - sustain) * (i - a) / max(dc, 1)
        elif i < n - r:
            env = sustain
        else:
            env = sustain * (n - i) / max(r, 1)
        result.append(s * env)
    return result


def pitch_sweep(start_freq, end_freq, duration, wave_fn=sine_wave, volume=0.4, sr=SAMPLE_RATE):
    n = int(sr * duration)
    samples = []
    for i in range(n):
        t = i / n
        freq = start_freq + (end_freq - start_freq) * t
        samples.append(volume * math.sin(2 * math.pi * freq * i / sr))
    return samples


def mix(*tracks):
    """Mix multiple sample lists together."""
    max_len = max(len(t) for t in tracks)
    result = [0.0] * max_len
    for track in tracks:
        for i, s in enumerate(track):
            result[i] += s
    # Normalize
    peak = max(abs(s) for s in result) or 1
    if peak > 1:
        result = [s / peak for s in result]
    return result


def generate_sfx():
    """Generate all sound effects."""
    # Jump
    jump = pitch_sweep(200, 600, 0.15, volume=0.4)
    jump = apply_envelope(jump, attack=0.005, decay=0.02, sustain=0.6, release=0.05)
    write_wav(os.path.join(SFX_DIR, 'jump.wav'), jump)

    # Coin collect
    coin1 = sine_wave(988, 0.07, 0.4)  # B5
    coin2 = sine_wave(1319, 0.12, 0.4)  # E6
    coin = apply_envelope(coin1 + coin2, attack=0.005, decay=0.01, sustain=0.8, release=0.03)
    write_wav(os.path.join(SFX_DIR, 'coin.wav'), coin)

    # Stomp
    stomp = mix(
        apply_envelope(square_wave(150, 0.1, 0.3), release=0.05),
        apply_envelope(noise(0.05, 0.2), release=0.02),
    )
    write_wav(os.path.join(SFX_DIR, 'stomp.wav'), stomp)

    # Power-up
    pu_samples = []
    for i in range(8):
        freq = 400 + i * 80
        pu_samples += sine_wave(freq, 0.06, 0.35)
    pu_samples = apply_envelope(pu_samples, attack=0.01, sustain=0.7, release=0.1)
    write_wav(os.path.join(SFX_DIR, 'powerup.wav'), pu_samples)

    # Damage / hit
    hit = mix(
        apply_envelope(square_wave(200, 0.2, 0.3), release=0.05),
        pitch_sweep(400, 100, 0.2, volume=0.3),
    )
    write_wav(os.path.join(SFX_DIR, 'hit.wav'), hit)

    # Death
    death_samples = []
    for i in range(6):
        freq = 500 - i * 60
        death_samples += square_wave(freq, 0.12, 0.3)
    death_samples = apply_envelope(death_samples, attack=0.01, sustain=0.5, release=0.2)
    write_wav(os.path.join(SFX_DIR, 'death.wav'), death_samples)

    # 1-UP
    oneup = []
    notes = [523, 659, 784, 1047]  # C E G C
    for note in notes:
        oneup += apply_envelope(sine_wave(note, 0.1, 0.4), release=0.02)
    write_wav(os.path.join(SFX_DIR, 'oneup.wav'), oneup)

    # Brick break
    brick = mix(
        apply_envelope(noise(0.15, 0.4), release=0.05),
        apply_envelope(square_wave(100, 0.1, 0.2), release=0.03),
    )
    write_wav(os.path.join(SFX_DIR, 'brick_break.wav'), brick)

    # Flag / level complete fanfare
    fanfare_notes = [523, 659, 784, 1047, 784, 1047, 1319]
    fanfare = []
    for note in fanfare_notes:
        fanfare += apply_envelope(
            mix(sine_wave(note, 0.2, 0.3), triangle_wave(note, 0.2, 0.2)),
            release=0.03,
        )
    write_wav(os.path.join(SFX_DIR, 'level_complete.wav'), fanfare)

    # Pause
    pause = apply_envelope(
        mix(square_wave(440, 0.1, 0.2), square_wave(330, 0.1, 0.2)),
        release=0.03,
    )
    write_wav(os.path.join(SFX_DIR, 'pause.wav'), pause)

    # Menu select
    sel = apply_envelope(sine_wave(880, 0.08, 0.3), release=0.02)
    write_wav(os.path.join(SFX_DIR, 'select.wav'), sel)

    print('  Sound effects generated.')


def generate_music():
    """Generate chiptune background music loops."""

    # === Main theme (upbeat platformer) ===
    bpm = 140
    beat = 60 / bpm

    # Melody (square wave)
    melody_notes = [
        (523, 0.5), (659, 0.5), (784, 0.5), (659, 0.25), (523, 0.25),
        (784, 0.5), (1047, 0.5), (784, 0.5), (659, 0.5),
        (587, 0.5), (659, 0.5), (784, 0.5), (659, 0.25), (587, 0.25),
        (523, 0.5), (659, 0.5), (784, 1.0),
        (440, 0.5), (523, 0.5), (659, 0.5), (523, 0.25), (440, 0.25),
        (659, 0.5), (784, 0.5), (659, 0.5), (523, 0.5),
        (587, 0.5), (523, 0.5), (440, 0.5), (523, 0.25), (587, 0.25),
        (659, 0.5), (523, 0.5), (440, 1.0),
    ]

    melody = []
    for freq, dur_beats in melody_notes:
        dur = dur_beats * beat
        note = apply_envelope(square_wave(freq, dur, 0.25), attack=0.01, sustain=0.6, release=dur*0.15)
        melody += note

    # Bass (triangle wave, root notes)
    bass_notes = [
        (131, 2), (165, 2), (196, 2), (165, 2),
        (147, 2), (165, 2), (131, 2), (196, 2),
        (110, 2), (131, 2), (165, 2), (131, 2),
        (147, 2), (131, 2), (110, 2), (131, 2),
    ]

    bass = []
    for freq, dur_beats in bass_notes:
        dur = dur_beats * beat
        note = apply_envelope(triangle_wave(freq, dur, 0.3), attack=0.01, sustain=0.7, release=dur*0.1)
        bass += note

    # Pad lengths
    max_len = max(len(melody), len(bass))
    melody += [0.0] * (max_len - len(melody))
    bass += [0.0] * (max_len - len(bass))

    # Simple percussion (noise hits on beats)
    perc = []
    total_dur = max_len / SAMPLE_RATE
    num_beats = int(total_dur / beat)
    perc = [0.0] * max_len
    for b in range(num_beats):
        start = int(b * beat * SAMPLE_RATE)
        if b % 2 == 0:
            # Kick-like
            kick = apply_envelope(pitch_sweep(150, 40, 0.06, volume=0.3), release=0.02)
            for j, s in enumerate(kick):
                if start + j < max_len:
                    perc[start + j] += s
        else:
            # Hi-hat-like
            hh = apply_envelope(noise(0.03, 0.15), release=0.01)
            for j, s in enumerate(hh):
                if start + j < max_len:
                    perc[start + j] += s

    theme = mix(melody, bass, perc)
    # Loop it twice for length
    theme = theme + theme
    write_wav(os.path.join(MUS_DIR, 'theme.wav'), theme)

    # === Underground / dark theme ===
    dark_notes = [
        (196, 0.5), (185, 0.5), (175, 0.5), (165, 0.75), (0, 0.25),
        (196, 0.5), (220, 0.5), (208, 0.5), (196, 0.75), (0, 0.25),
        (262, 0.5), (247, 0.5), (233, 0.5), (220, 0.75), (0, 0.25),
        (196, 0.5), (185, 0.5), (165, 0.5), (147, 1.0),
    ]
    dark_melody = []
    for freq, dur_beats in dark_notes:
        dur = dur_beats * beat
        if freq > 0:
            note = apply_envelope(triangle_wave(freq, dur, 0.25), attack=0.02, sustain=0.5, release=dur*0.3)
        else:
            note = [0.0] * int(SAMPLE_RATE * dur)
        dark_melody += note

    dark_bass_notes = [(65, 4), (73, 4), (82, 4), (65, 4)]
    dark_bass = []
    for freq, dur_beats in dark_bass_notes:
        dur = dur_beats * beat
        note = apply_envelope(triangle_wave(freq, dur, 0.3), attack=0.02, sustain=0.6, release=dur*0.2)
        dark_bass += note

    dmax = max(len(dark_melody), len(dark_bass))
    dark_melody += [0.0] * (dmax - len(dark_melody))
    dark_bass += [0.0] * (dmax - len(dark_bass))

    underground = mix(dark_melody, dark_bass)
    underground = underground + underground
    write_wav(os.path.join(MUS_DIR, 'underground.wav'), underground)

    # === Boss theme (intense) ===
    boss_notes = [
        (330, 0.25), (330, 0.25), (0, 0.25), (330, 0.25),
        (262, 0.25), (330, 0.25), (392, 0.5),
        (196, 0.5), (0, 0.5),
        (330, 0.25), (330, 0.25), (0, 0.25), (330, 0.25),
        (262, 0.25), (330, 0.25), (440, 0.5),
        (392, 0.5), (0, 0.5),
    ]
    boss_melody = []
    fast_beat = 60 / 160
    for freq, dur_beats in boss_notes:
        dur = dur_beats * fast_beat
        if freq > 0:
            note = apply_envelope(square_wave(freq, dur, 0.3), attack=0.005, sustain=0.7, release=dur*0.1)
        else:
            note = [0.0] * int(SAMPLE_RATE * dur)
        boss_melody += note

    boss_bass_line = []
    bb_notes = [(110, 1), (131, 1), (110, 1), (147, 1)] * 2
    for freq, dur_beats in bb_notes:
        dur = dur_beats * fast_beat
        note = apply_envelope(triangle_wave(freq, dur, 0.35), attack=0.01, sustain=0.6, release=dur*0.1)
        boss_bass_line += note

    bmax = max(len(boss_melody), len(boss_bass_line))
    boss_melody += [0.0] * (bmax - len(boss_melody))
    boss_bass_line += [0.0] * (bmax - len(boss_bass_line))

    boss_theme = mix(boss_melody, boss_bass_line)
    boss_theme = boss_theme + boss_theme + boss_theme
    write_wav(os.path.join(MUS_DIR, 'boss.wav'), boss_theme)

    print('  Music tracks generated.')


# ============================================================
# MAIN
# ============================================================

def generate_all():
    print('Generating Super JT World assets...')
    ensure_dirs()

    # --- JT sprites ---
    print('  Generating JT sprites...')
    make_jt_idle(32).save(os.path.join(TEX_DIR, 'jt_idle.png'))
    for i in range(4):
        make_jt_run(32, i).save(os.path.join(TEX_DIR, f'jt_run_{i}.png'))
    make_jt_jump(32).save(os.path.join(TEX_DIR, 'jt_jump.png'))

    # --- Enemies ---
    print('  Generating enemy sprites...')
    make_goomba(32).save(os.path.join(TEX_DIR, 'enemy_goomba.png'))
    make_koopa(32).save(os.path.join(TEX_DIR, 'enemy_koopa.png'))
    make_flying_enemy(32).save(os.path.join(TEX_DIR, 'enemy_flying.png'))
    make_boss(64).save(os.path.join(TEX_DIR, 'enemy_boss.png'))

    # --- Power-ups ---
    print('  Generating power-up sprites...')
    make_mushroom(32).save(os.path.join(TEX_DIR, 'powerup_mushroom.png'))
    make_star(32).save(os.path.join(TEX_DIR, 'powerup_star.png'))
    make_fire_flower(32).save(os.path.join(TEX_DIR, 'powerup_fire_flower.png'))
    make_feather(32).save(os.path.join(TEX_DIR, 'powerup_feather.png'))

    # --- Coin ---
    print('  Generating coin...')
    make_coin(32).save(os.path.join(TEX_DIR, 'coin.png'))

    # --- Per-theme tiles ---
    print('  Generating themed tiles...')
    for theme in THEMES:
        pal = THEME_PALETTES[theme]
        theme_dir = os.path.join(TEX_DIR, theme)
        make_ground_tile(pal, 32).save(os.path.join(theme_dir, 'ground.png'))
        make_brick_tile(pal, 32).save(os.path.join(theme_dir, 'brick.png'))
        make_question_tile(pal, 32).save(os.path.join(theme_dir, 'question.png'))
        make_pipe_tile(pal, 32).save(os.path.join(theme_dir, 'pipe.png'))
        make_background(pal, 128, 128).save(os.path.join(theme_dir, 'background.png'))

    # --- Sounds ---
    print('  Generating sound effects...')
    generate_sfx()

    # --- Music ---
    print('  Generating music...')
    generate_music()

    print('Done! All assets saved to:', ASSET_DIR)


if __name__ == '__main__':
    generate_all()
